<?php 

const BR = '<br>';