<?php
// session_set_cookie_params(0, '/', 'localhost',false,true);
// session_start();