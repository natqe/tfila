
function idFrom(uri){
  return decodeURI(uri.split('/').pop());
};