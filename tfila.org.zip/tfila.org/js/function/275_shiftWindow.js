
function shiftWindow() { 
    scrollBy(0, -(header.offsetHeight+10));
}
